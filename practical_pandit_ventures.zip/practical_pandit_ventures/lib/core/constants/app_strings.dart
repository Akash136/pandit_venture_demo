class AppStrings {
  static const String appName = 'Practical Pandit Ventures';
  static const String featuredProducts = 'Featured Products';
  static const String cachedProducts = 'Cached Products';
  static const String loading = 'Loading...';
  static const String error = 'Error';
  static const String retry = 'Retry';
  static const String noData = 'No data available';
  static const String price = 'Price: \$';
  static const String rating = 'Rating: ';
  static const String category = 'Category: ';
} 