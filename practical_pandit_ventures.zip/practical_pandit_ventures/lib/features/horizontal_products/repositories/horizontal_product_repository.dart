import 'package:practical_pandit_ventures/core/services/api_service.dart';
import 'package:practical_pandit_ventures/features/horizontal_products/models/product_model.dart';

class HorizontalProductRepository {
  final ApiService _apiService;

  HorizontalProductRepository(this._apiService);

  Future<List<ProductModel>> getProducts({
    required int offset,
    required int limit,
  }) async {
    try {
      final response = await _apiService.getProducts(
        offset: offset,
        limit: limit,
      );
      return response.map((json) => ProductModel.fromJson(json)).toList();
    } catch (e) {
      throw Exception('Failed to fetch products: $e');
    }
  }
} 