import 'package:get/get.dart';
import 'package:practical_pandit_ventures/core/services/api_service.dart';
import 'package:practical_pandit_ventures/features/horizontal_products/models/product_model.dart';
import 'package:practical_pandit_ventures/features/horizontal_products/repositories/horizontal_product_repository.dart';

class FeaturedProductsController extends GetxController {
  final HorizontalProductRepository _repository;
  final RxList<ProductModel> products = <ProductModel>[].obs;
  final RxBool isLoading = false.obs;
  final RxBool hasMore = true.obs;
  final int pageSize = 10;
  int currentPage = 0;

  FeaturedProductsController() : _repository = HorizontalProductRepository(ApiService());

  @override
  void onInit() {
    super.onInit();
    loadProducts();
  }

  Future<void> loadProducts() async {
    if (isLoading.value || !hasMore.value) return;

    try {
      isLoading.value = true;
      final newProducts = await _repository.getProducts(
        offset: currentPage * pageSize,
        limit: pageSize,
      );

      if (newProducts.isEmpty) {
        hasMore.value = false;
      } else {
        products.addAll(newProducts);
        currentPage++;
      }
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to load products: $e',
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> refreshProducts() async {
    currentPage = 0;
    products.clear();
    hasMore.value = true;
    await loadProducts();
  }
} 