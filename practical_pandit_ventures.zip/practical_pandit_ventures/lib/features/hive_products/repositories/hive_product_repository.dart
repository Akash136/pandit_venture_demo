import 'package:hive/hive.dart';
import 'package:practical_pandit_ventures/core/services/api_service.dart';
import 'package:practical_pandit_ventures/features/hive_products/models/hive_product_model.dart';

class HiveProductRepository {
  final ApiService _apiService;
  final Box<HiveProductModel> _box;

  HiveProductRepository(this._apiService, this._box);

  Future<List<HiveProductModel>> getProducts({
    required int offset,
    required int limit,
  }) async {
    try {
      // First try to get products from Hive
      final cachedProducts = _box.values.skip(offset).take(limit).toList();
      
      if (cachedProducts.length == limit) {
        return cachedProducts;
      }

      // If not enough products in Hive, fetch from API
      final apiProducts = await _apiService.getProducts(
        offset: offset,
        limit: limit,
      );

      // Convert API products to Hive models and store them
      final hiveProducts = apiProducts.map((json) {
        final product = HiveProductModel.fromJson(json);
        _box.put(product.id, product);
        return product;
      }).toList();

      return hiveProducts;
    } catch (e) {
      // If API fails, return whatever we have in Hive
      return _box.values.skip(offset).take(limit).toList();
    }
  }

  List<HiveProductModel> getStoredProducts() {
    return _box.values.toList();
  }
} 