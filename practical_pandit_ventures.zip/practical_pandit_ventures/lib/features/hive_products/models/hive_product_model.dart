import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:hive/hive.dart';

part 'hive_product_model.freezed.dart';
part 'hive_product_model.g.dart';

@freezed
@HiveType(typeId: 0)
class HiveProductModel with _$HiveProductModel {
  @HiveField(0)
  const factory HiveProductModel({
    @HiveField(1) required int id,
    @HiveField(2) required String title,
    @HiveField(3) required double price,
    @HiveField(4) required String description,
    @HiveField(5) required String category,
    @HiveField(6) required String image,
    @HiveField(7) required Rating rating,
  }) = _HiveProductModel;

  factory HiveProductModel.fromJson(Map<String, dynamic> json) =>
      _$HiveProductModelFromJson(json);
}

@freezed
@HiveType(typeId: 1)
class Rating with _$Rating {
  @HiveField(0)
  const factory Rating({
    @HiveField(1) required double rate,
    @HiveField(2) required int count,
  }) = _Rating;

  factory Rating.fromJson(Map<String, dynamic> json) => _$RatingFromJson(json);
} 