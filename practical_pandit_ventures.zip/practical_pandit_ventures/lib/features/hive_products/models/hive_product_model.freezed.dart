// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'hive_product_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

HiveProductModel _$HiveProductModelFromJson(Map<String, dynamic> json) {
  return _HiveProductModel.fromJson(json);
}

/// @nodoc
mixin _$HiveProductModel {
  @HiveField(1)
  int get id => throw _privateConstructorUsedError;
  @HiveField(2)
  String get title => throw _privateConstructorUsedError;
  @HiveField(3)
  double get price => throw _privateConstructorUsedError;
  @HiveField(4)
  String get description => throw _privateConstructorUsedError;
  @HiveField(5)
  String get category => throw _privateConstructorUsedError;
  @HiveField(6)
  String get image => throw _privateConstructorUsedError;
  @HiveField(7)
  Rating get rating => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $HiveProductModelCopyWith<HiveProductModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HiveProductModelCopyWith<$Res> {
  factory $HiveProductModelCopyWith(
          HiveProductModel value, $Res Function(HiveProductModel) then) =
      _$HiveProductModelCopyWithImpl<$Res, HiveProductModel>;
  @useResult
  $Res call(
      {@HiveField(1) int id,
      @HiveField(2) String title,
      @HiveField(3) double price,
      @HiveField(4) String description,
      @HiveField(5) String category,
      @HiveField(6) String image,
      @HiveField(7) Rating rating});

  $RatingCopyWith<$Res> get rating;
}

/// @nodoc
class _$HiveProductModelCopyWithImpl<$Res, $Val extends HiveProductModel>
    implements $HiveProductModelCopyWith<$Res> {
  _$HiveProductModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? title = null,
    Object? price = null,
    Object? description = null,
    Object? category = null,
    Object? image = null,
    Object? rating = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      price: null == price
          ? _value.price
          : price // ignore: cast_nullable_to_non_nullable
              as double,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      category: null == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      rating: null == rating
          ? _value.rating
          : rating // ignore: cast_nullable_to_non_nullable
              as Rating,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $RatingCopyWith<$Res> get rating {
    return $RatingCopyWith<$Res>(_value.rating, (value) {
      return _then(_value.copyWith(rating: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$HiveProductModelImplCopyWith<$Res>
    implements $HiveProductModelCopyWith<$Res> {
  factory _$$HiveProductModelImplCopyWith(_$HiveProductModelImpl value,
          $Res Function(_$HiveProductModelImpl) then) =
      __$$HiveProductModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@HiveField(1) int id,
      @HiveField(2) String title,
      @HiveField(3) double price,
      @HiveField(4) String description,
      @HiveField(5) String category,
      @HiveField(6) String image,
      @HiveField(7) Rating rating});

  @override
  $RatingCopyWith<$Res> get rating;
}

/// @nodoc
class __$$HiveProductModelImplCopyWithImpl<$Res>
    extends _$HiveProductModelCopyWithImpl<$Res, _$HiveProductModelImpl>
    implements _$$HiveProductModelImplCopyWith<$Res> {
  __$$HiveProductModelImplCopyWithImpl(_$HiveProductModelImpl _value,
      $Res Function(_$HiveProductModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? title = null,
    Object? price = null,
    Object? description = null,
    Object? category = null,
    Object? image = null,
    Object? rating = null,
  }) {
    return _then(_$HiveProductModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      price: null == price
          ? _value.price
          : price // ignore: cast_nullable_to_non_nullable
              as double,
      description: null == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String,
      category: null == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as String,
      image: null == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String,
      rating: null == rating
          ? _value.rating
          : rating // ignore: cast_nullable_to_non_nullable
              as Rating,
    ));
  }
}

/// @nodoc
@JsonSerializable()
@HiveField(0)
class _$HiveProductModelImpl implements _HiveProductModel {
  const _$HiveProductModelImpl(
      {@HiveField(1) required this.id,
      @HiveField(2) required this.title,
      @HiveField(3) required this.price,
      @HiveField(4) required this.description,
      @HiveField(5) required this.category,
      @HiveField(6) required this.image,
      @HiveField(7) required this.rating});

  factory _$HiveProductModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$HiveProductModelImplFromJson(json);

  @override
  @HiveField(1)
  final int id;
  @override
  @HiveField(2)
  final String title;
  @override
  @HiveField(3)
  final double price;
  @override
  @HiveField(4)
  final String description;
  @override
  @HiveField(5)
  final String category;
  @override
  @HiveField(6)
  final String image;
  @override
  @HiveField(7)
  final Rating rating;

  @override
  String toString() {
    return 'HiveProductModel(id: $id, title: $title, price: $price, description: $description, category: $category, image: $image, rating: $rating)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$HiveProductModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.title, title) || other.title == title) &&
            (identical(other.price, price) || other.price == price) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.category, category) ||
                other.category == category) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.rating, rating) || other.rating == rating));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, id, title, price, description, category, image, rating);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$HiveProductModelImplCopyWith<_$HiveProductModelImpl> get copyWith =>
      __$$HiveProductModelImplCopyWithImpl<_$HiveProductModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$HiveProductModelImplToJson(
      this,
    );
  }
}

abstract class _HiveProductModel implements HiveProductModel {
  const factory _HiveProductModel(
      {@HiveField(1) required final int id,
      @HiveField(2) required final String title,
      @HiveField(3) required final double price,
      @HiveField(4) required final String description,
      @HiveField(5) required final String category,
      @HiveField(6) required final String image,
      @HiveField(7) required final Rating rating}) = _$HiveProductModelImpl;

  factory _HiveProductModel.fromJson(Map<String, dynamic> json) =
      _$HiveProductModelImpl.fromJson;

  @override
  @HiveField(1)
  int get id;
  @override
  @HiveField(2)
  String get title;
  @override
  @HiveField(3)
  double get price;
  @override
  @HiveField(4)
  String get description;
  @override
  @HiveField(5)
  String get category;
  @override
  @HiveField(6)
  String get image;
  @override
  @HiveField(7)
  Rating get rating;
  @override
  @JsonKey(ignore: true)
  _$$HiveProductModelImplCopyWith<_$HiveProductModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

Rating _$RatingFromJson(Map<String, dynamic> json) {
  return _Rating.fromJson(json);
}

/// @nodoc
mixin _$Rating {
  @HiveField(1)
  double get rate => throw _privateConstructorUsedError;
  @HiveField(2)
  int get count => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RatingCopyWith<Rating> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RatingCopyWith<$Res> {
  factory $RatingCopyWith(Rating value, $Res Function(Rating) then) =
      _$RatingCopyWithImpl<$Res, Rating>;
  @useResult
  $Res call({@HiveField(1) double rate, @HiveField(2) int count});
}

/// @nodoc
class _$RatingCopyWithImpl<$Res, $Val extends Rating>
    implements $RatingCopyWith<$Res> {
  _$RatingCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? rate = null,
    Object? count = null,
  }) {
    return _then(_value.copyWith(
      rate: null == rate
          ? _value.rate
          : rate // ignore: cast_nullable_to_non_nullable
              as double,
      count: null == count
          ? _value.count
          : count // ignore: cast_nullable_to_non_nullable
              as int,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$RatingImplCopyWith<$Res> implements $RatingCopyWith<$Res> {
  factory _$$RatingImplCopyWith(
          _$RatingImpl value, $Res Function(_$RatingImpl) then) =
      __$$RatingImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({@HiveField(1) double rate, @HiveField(2) int count});
}

/// @nodoc
class __$$RatingImplCopyWithImpl<$Res>
    extends _$RatingCopyWithImpl<$Res, _$RatingImpl>
    implements _$$RatingImplCopyWith<$Res> {
  __$$RatingImplCopyWithImpl(
      _$RatingImpl _value, $Res Function(_$RatingImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? rate = null,
    Object? count = null,
  }) {
    return _then(_$RatingImpl(
      rate: null == rate
          ? _value.rate
          : rate // ignore: cast_nullable_to_non_nullable
              as double,
      count: null == count
          ? _value.count
          : count // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc
@JsonSerializable()
@HiveField(0)
class _$RatingImpl implements _Rating {
  const _$RatingImpl(
      {@HiveField(1) required this.rate, @HiveField(2) required this.count});

  factory _$RatingImpl.fromJson(Map<String, dynamic> json) =>
      _$$RatingImplFromJson(json);

  @override
  @HiveField(1)
  final double rate;
  @override
  @HiveField(2)
  final int count;

  @override
  String toString() {
    return 'Rating(rate: $rate, count: $count)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RatingImpl &&
            (identical(other.rate, rate) || other.rate == rate) &&
            (identical(other.count, count) || other.count == count));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, rate, count);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RatingImplCopyWith<_$RatingImpl> get copyWith =>
      __$$RatingImplCopyWithImpl<_$RatingImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RatingImplToJson(
      this,
    );
  }
}

abstract class _Rating implements Rating {
  const factory _Rating(
      {@HiveField(1) required final double rate,
      @HiveField(2) required final int count}) = _$RatingImpl;

  factory _Rating.fromJson(Map<String, dynamic> json) = _$RatingImpl.fromJson;

  @override
  @HiveField(1)
  double get rate;
  @override
  @HiveField(2)
  int get count;
  @override
  @JsonKey(ignore: true)
  _$$RatingImplCopyWith<_$RatingImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
