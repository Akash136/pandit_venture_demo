import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:practical_pandit_ventures/features/hive_products/models/hive_product_model.dart';
import 'package:practical_pandit_ventures/features/hive_products/repositories/hive_product_repository.dart';
import '../../../core/services/api_service.dart';

class CachedProductsController extends GetxController {
  late final HiveProductRepository _repository;
  final RxList<HiveProductModel> products = <HiveProductModel>[].obs;
  final RxBool isLoading = false.obs;
  final RxBool hasMore = true.obs;
  final RxBool isInitialized = false.obs;
  final int pageSize = 10;
  int currentPage = 0;

  @override
  void onInit() {
    super.onInit();
    _initializeRepository();
  }

  Future<void> _initializeRepository() async {
    try {
      final box = await Hive.openBox<HiveProductModel>('products');
      _repository = HiveProductRepository(ApiService(), box);
      isInitialized.value = true;
      await loadProducts();
    } catch (e) {
      print('Error initializing repository: $e');
      // We'll show the error in the UI instead of using snackbar
    }
  }

  Future<void> loadProducts() async {
    if (!isInitialized.value || isLoading.value || !hasMore.value) return;

    try {
      isLoading.value = true;
      final newProducts = await _repository.getProducts(
        offset: currentPage * pageSize,
        limit: pageSize,
      );

      if (newProducts.isEmpty) {
        refreshProducts();
        hasMore.value = false;
      } else {
        products.addAll(newProducts);
        currentPage++;
      }
    } catch (e) {
      print('Error loading products: $e');
      // We'll show the error in the UI instead of using snackbar
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> refreshProducts() async {
    if (!isInitialized.value) return;
    
    currentPage = 0;
    products.clear();
    hasMore.value = true;
    await loadProducts();
  }
} 