import 'package:flutter/material.dart';
import 'package:practical_pandit_ventures/core/constants/app_colors.dart';
import 'package:practical_pandit_ventures/core/constants/app_strings.dart';
import 'package:practical_pandit_ventures/features/horizontal_products/screens/featured_products_screen.dart';
import 'package:practical_pandit_ventures/features/hive_products/screens/cached_products_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.appName),
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.onPrimary,
      ),
      body: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(
              AppStrings.featuredProducts,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          SizedBox(height: 200, child: FeaturedProductsScreen()),
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(
              AppStrings.cachedProducts,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          SizedBox(height: 16),
          Expanded(child: CachedProductsScreen()),
        ],
      ),
    );
  }
} 