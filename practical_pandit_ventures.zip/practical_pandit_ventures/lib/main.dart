import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:practical_pandit_ventures/core/constants/app_colors.dart';
import 'package:practical_pandit_ventures/features/hive_products/controllers/cached_products_controller.dart';
import 'package:practical_pandit_ventures/features/hive_products/models/hive_product_model.dart';
import 'package:practical_pandit_ventures/features/horizontal_products/controllers/featured_products_controller.dart';
import 'package:practical_pandit_ventures/features/home/screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  Hive.registerAdapter(HiveProductModelAdapter());
  Hive.registerAdapter(RatingAdapter());
  await Hive.openBox<HiveProductModel>('products');
  
  // Initialize GetX
  Get.put(FeaturedProductsController());
  Get.put(CachedProductsController());
  
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Practical Pandit Ventures',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.primary,
          primary: AppColors.primary,
          secondary: AppColors.secondary,
          background: AppColors.background,
          surface: AppColors.surface,
          error: AppColors.error,
          onPrimary: AppColors.onPrimary,
          onSecondary: AppColors.onSecondary,
          onBackground: AppColors.onBackground,
          onSurface: AppColors.onSurface,
          onError: AppColors.onError,
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
