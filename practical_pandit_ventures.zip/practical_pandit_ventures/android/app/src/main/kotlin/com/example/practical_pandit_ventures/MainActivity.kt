package com.example.practical_pandit_ventures

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
